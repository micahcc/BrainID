namespace indii {
  namespace ml {
    namespace data {

/**
 * @namespace indii::ml::data Convenience classes for %data input and
 * output.
 */

    }
  }
}

//#if defined(__GNUC__) && defined(GCC_PCH)
//  #include "../aux/aux.hpp"
//#endif

#include "FunctionModel.hpp"

using namespace indii::ml::ode;

FunctionModel::~FunctionModel() {
  //
}

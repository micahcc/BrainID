namespace indii {
  namespace ml {
    namespace aux {

/**
 * @namespace indii::ml::aux Auxiliary components, including matrices,
 * vectors, probability distributions and stochastic processes.
 */

    }
  }
}

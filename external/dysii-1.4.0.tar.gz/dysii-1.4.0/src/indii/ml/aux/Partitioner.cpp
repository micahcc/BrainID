#include "Partitioner.hpp"

using namespace indii::ml::aux;

Partitioner::~Partitioner() {
  //
}


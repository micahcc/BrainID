#include "Almost2Norm.hpp"

using namespace indii::ml::aux;

Almost2Norm::~Almost2Norm() {
  //
}


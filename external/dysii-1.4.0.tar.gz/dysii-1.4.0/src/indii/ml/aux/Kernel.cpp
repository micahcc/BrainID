#include "Kernel.hpp"

using namespace indii::ml::aux;

Kernel::Kernel() {
  //
}

Kernel::Kernel(const double h) {
  this->h = h;
}

Kernel::~Kernel() {
  //
}


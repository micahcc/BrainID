#include "Norm.hpp"

using namespace indii::ml::aux;

Norm::~Norm() {
  //
}


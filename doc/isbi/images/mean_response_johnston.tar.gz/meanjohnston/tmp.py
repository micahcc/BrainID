#!/usr/bin/python

import pylab as P
import sys
import nibabel 
from numpy import convolve
import scipy.stats
from scipy.stats.distributions import gamma
import scipy.io as io
from math import isinf


def readStim(filename):
    stimin = open(filename)
    stims = [[float(var) for var in line.split()] for line in stimin.readlines()]
    print stims
    return stims

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print "Two Args: the timeseries to plot and the stimfile to plot with it"
        sys.exit(-1);
    
    actual = nibabel.load(sys.argv[1])
    
    TR = actual.get_header()['pixdim'][4];
    if TR == 1:
        print "Pixdim is 1, changing to 2.1"
        TR = 2.1
    P.plot([i*TR for i in range(0, len(actual.get_data()[0,0,0, :]))], \
                actual.get_data()[0,0,0,:]);
    
    stims = readStim(sys.argv[2])
    
    times = [val[0] for val in stims if val[1] > 0]
    print times

    first = True
    for time_i in times:
        P.plot([time_i, time_i], [-.0003, -.0004], 'r')
        if first:
            P.legend(["Mean Response", "Stimulus Application"])
        
    P.show()




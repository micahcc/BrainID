#!/usr/bin/python

import pylab as P
import sys
import random
from math import sqrt

num = []
for val in sys.stdin.readlines():
    num.append(float(val))
P.hist(num, 40);
P.show()

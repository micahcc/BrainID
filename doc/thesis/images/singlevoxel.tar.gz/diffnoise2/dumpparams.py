#!/usr/bin/python

from matplotlib.widgets import Slider, Button, RadioButtons
import pylab
import sys
import nibabel
import time
import numpy

images = list()
for arg in sys.argv[1:]:
    print arg
    images.append(nibabel.load(arg))
pos = (0,0,0)

avg = [0 for i in range(8)]
for img in images:
    total = 0
    for i in range(0, 7):
        if i == 0 or i == 4 or i == 5:
            total = total + img.get_data()[pos[0], pos[1], pos[2], i]
        print round(img.get_data()[pos[0],pos[1], pos[2],i], 5), "&" , 
        avg[i] = avg[i] + img.get_data()[pos[0],pos[1], pos[2],i]
    avg[7] = avg[7] + total
    print round(total, 5),
    print '\\\\'

for i in range(7):
    print round(avg[i]/len(images), 5), "&",
print round(avg[7]/len(images), 5), "\\\\"
    

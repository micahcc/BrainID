#!/usr/bin/python

from matplotlib.widgets import Slider, Button, RadioButtons
import pylab
import sys
import nibabel
import time
import numpy
from math import sqrt

images = list()
for arg in sys.argv[1:]:
    print arg
    images.append(nibabel.load(arg))
pos = (0,0,0)

avg = 0 
for img in images:
    print round(sqrt(img.get_data()[0,0,0]), 8)
    avg = avg + sqrt(img.get_data()[0,0,0])

print round(avg/len(images), 8)


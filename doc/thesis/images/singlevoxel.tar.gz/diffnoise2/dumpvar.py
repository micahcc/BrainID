#!/usr/bin/python

from matplotlib.widgets import Slider, Button, RadioButtons
import pylab
import sys
import nibabel
import time
import numpy

images = list()
for arg in sys.argv[1:]:
    print arg
    images.append(nibabel.load(arg))
pos = (0,0,0)

for img in images:
    total = 0
    for i in range(0, 7):
        for j in range(0, 6):
            print round(img.get_data()[pos[0],pos[1], pos[2],i,j], 7), "&" , 
        print round(img.get_data()[pos[0],pos[1], pos[2],i,j+1], 7), "\\\\" 

    

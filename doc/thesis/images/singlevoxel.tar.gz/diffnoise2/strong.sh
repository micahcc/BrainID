#!/bin/bash
for i in `seq 0 10`; do 
out=LOWNOISE-$i-w0
#mkdir $out
#~/brainid/build/code/boldgen -X0file params -istim stim -st .00005 -bf truebold.nii.gz -ot 2.1 -sf truestate.nii.gz -c 1000 -snr .001 -drift .0005
#mv *nii.gz $out
echo mpirun -n 4 ~/brainid/build/code/parammap_calc  $out/carrier-truebold.nii.gz  -l 0 -S 0 -t 2.1  -p 1000 -d 1500 -s stim -f 0 -w 0 -C .005   -o $out/ -e 0 -D 0 
mpirun -n 4 ~/brainid/build/code/parammap_calc  $out/carrier-truebold.nii.gz  -l 0 -S 0 -t 2.1  -p 1000 -d 1500 -s stim -f 0 -w 0 -C .005   -o $out/ -e 0 -D 0 &> $out/out
cp $0 $out/command2
done
